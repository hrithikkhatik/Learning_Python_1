from tkinter import *

expression = ""

def press(num):
    global expression
    expression = expression + str(num)
    equation.set(expression)

def clear():
    global expression
    expression = ""
    equation.set("")

def equalpress():
    global expression
    try:
        total = str(eval(expression))
        equation.set(total)
        expression = ""
    except:
        equation.set("error")
        expression = ""

root = Tk()
root.title("Calculator")
root.geometry("300x400")

equation = StringVar()

entry = Entry(root, textvariable=equation, font=("Arial", 20), bd=8, relief="ridge", justify="right")
entry.grid(row=0, column=0, columnspan=4, ipadx=8, ipady=8)

buttons = [
    ("7",1,0), ("8",1,1), ("9",1,2), ("+",1,3),
    ("4",2,0), ("5",2,1), ("6",2,2), ("-",2,3),
    ("1",3,0), ("2",3,1), ("3",3,2), ("*",3,3),
    ("0",4,0), ("C",4,1), ("=",4,2), ("/",4,3),
]

for (text, row, col) in buttons:
    if text == "=":
        b = Button(root, text=text, width=5, height=2, font=("Arial",14), command=equalpress)
    elif text == "C":
        b = Button(root, text=text, width=5, height=2, font=("Arial",14), command=clear)
    else:
        b = Button(root, text=text, width=5, height=2, font=("Arial",14), command=lambda t=text: press(t))
    b.grid(row=row, column=col, padx=5, pady=5)

root.mainloop()
