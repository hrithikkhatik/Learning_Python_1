# Integrated Django Auth Project

Run with:
```
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```
